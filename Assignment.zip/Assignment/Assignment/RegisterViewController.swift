//
//  RegisterViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class RegisterViewController: UIViewController {

    @IBAction func cancelButtonClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var userEmail: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    @IBOutlet weak var userRepeatPassword: UITextField!
    @IBOutlet weak var userName: UITextField!
    
    @IBAction func signInButtonClicked(_ sender: Any) {
        let name = userName.text
        let email = userEmail.text
        let password = userPassword.text
        let repeatPassword = userRepeatPassword.text
        
        if (name?.isEmpty)! || (password?.isEmpty)! || (repeatPassword?.isEmpty)! || (email?.isEmpty)!{
            AlertController.showAlert(inViewController: self, title: "Alert", message: "All fields are required!")
            
        }
        
        if password != repeatPassword {
            AlertController.showAlert(inViewController: self, title: "Alert", message: "Passwords does'nt match! Try again")
            
        }
        
        Auth.auth().createUser(withEmail: email!, password: password!) { (user, error) in
            guard error == nil else {
                AlertController.showAlert(inViewController: self, title: "Error", message: (error?.localizedDescription)!)
                return
            }
            //let changeRequest = user?.p
            //changeRequest?.username = name
            //changeRequest.commitChanges
            
            let ref = Database.database().reference()
            let usersReference = ref.child("users")
            let uid = user?.user.uid
            let newUserReference = usersReference.child(uid!)
        
            newUserReference.setValue(["UserName": self.userName.text, "Email": self.userEmail.text])
            
            self.dismiss(animated: true, completion: nil)
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
