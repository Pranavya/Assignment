//
//  ComplaintViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit

class ComplaintViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logoutButtonClicked(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        UserDefaults.standard.synchronize()
        
        performSegue(withIdentifier: "HomePage", sender: nil)
//        let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
//        self.present(homeViewController, animated: true, completion: nil)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
