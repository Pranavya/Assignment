//
//  ComplaintsListViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit
import Firebase


class ComplaintsListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchData()
        // Do any additional setup after loading the view.
    }
    var ref = Database.database().reference().child("users")
    func fetchData() {
        ref.observeSingleEvent(of: .value, with: { snapshot in
            
            if snapshot.value is NSNull {

            } else {
                for child in snapshot.children {
                  
//                    let name = child.value["name"] as? String
                    print(child)
                }
//                print("\(friendsList)")
            }
        })

//
//        ref.observeSingleEventOfType(.childAdded, sigblock{snapshot in
//            print("User Found")
//            print(snapshot)
//        },withCancelBlock:nil)
   }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
