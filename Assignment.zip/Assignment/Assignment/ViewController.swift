//
//  ViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

