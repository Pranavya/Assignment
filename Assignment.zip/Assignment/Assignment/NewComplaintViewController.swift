//
//  NewComplaintViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth

class NewComplaintViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var subject: UITextField!
    @IBOutlet weak var descriptionOfComplaint: UITextField!
    @IBOutlet weak var typeOfComplaint: UITextField!
    let myPickerView = UIPickerView()
    let arr = ["Technical", "Product", "Process", "Forgot Password", "Others"]
    var ref: DatabaseReference!
    var complaint = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        typeOfComplaint.delegate = self
        myPickerView.delegate = self
        myPickerView.dataSource = self
        typeOfComplaint.inputView = myPickerView
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(NewComplaintViewController.viewTapped(gestureRecognizer:)))
        view.addGestureRecognizer(tapGesture)
        // Do any additional setup after loading the view.
    }
    
    var currentArr: [String] = []
    var activeTextField : UITextField!
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        activeTextField = textField
        switch textField {
        case typeOfComplaint:
            currentArr = arr
        default:
            print("Default")
        }
        return true
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currentArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currentArr[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        activeTextField.text = currentArr[row]
    }
    
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer) {
        view.endEditing(true)
    }

    @IBAction func submitButtonClicked(_ sender: Any) {
        let sub = subject.text
        let desc = descriptionOfComplaint.text
        let type = typeOfComplaint.text
        if (sub == nil || desc == nil || type == nil) {
            AlertController.showAlert(inViewController: self, title: "Alert", message: "All fields are required")
        }
        else {
            complaint.append(sub!)
            complaint.append(desc!)
            complaint.append(type!)
        
            ref = Database.database().reference()
            if let user = Auth.auth().currentUser {
                self.ref.child("users").child(user.uid).child("Complaints").setValue(complaint)
            }
        }
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
