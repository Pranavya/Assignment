//
//  LoginViewController.swift
//  Assignment
//
//  Created by Pranavya P on 02/07/19.
//  Copyright © 2019 Pranavya P. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseCore

class LoginViewController: UIViewController {

    @IBOutlet weak var emailId: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBAction func cancelButtonClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    static var uid: String!
    
    @IBAction func signInButtonClicked(_ sender: Any) {
        if self.emailId?.text == "" || self.password?.text == "" {
            AlertController.showAlert(inViewController: self, title: "Alert!", message: "Enter Username and Password")
            print("Please Enter Some Text")
        }
        else {
            Auth.auth().signIn(withEmail: emailId.text!, password: password.text!) { (user, error) in
                if user != nil {
                    
                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
                    UserDefaults.standard.synchronize()
                    let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "ComplaintViewController")as! ComplaintViewController
                    LoginViewController.uid = user?.user.uid
                    print(LoginViewController.uid as Any)
                    self.present(homeViewController, animated: true, completion: nil)
                    
                }
                if error != nil {
                    AlertController.showAlert(inViewController: self, title: "Error!", message: (error?.localizedDescription)!)
                }
                
            }
        }
    }
    @IBAction func registerButtonClicked(_ sender: Any) {
        let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController")as! RegisterViewController
        self.present(homeViewController, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
